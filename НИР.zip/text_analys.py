def text_analys(my_string):
    my_string_1 = my_string
    return  my_string_1