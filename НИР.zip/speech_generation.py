def speech_generation(my_string):
    return  my_string