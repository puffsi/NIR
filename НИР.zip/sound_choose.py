def sound_choose(my_string_1):
    my_string_2 = my_string_1

    return  my_string_2