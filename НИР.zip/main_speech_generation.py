import text_analys
import speech_generation
import sound_choose
my_string = '' #пустая строка для записи в нее цепочки из файла
i = 0
f = open('Text.txt', 'r') #открываем файл на чтение
my_string = f.readlines()
print(my_string) #получаем результат от блока генерации речи
f.close #закрываем файл
my_string_1 = text_analys.text_analys(my_string)
my_string_2 = sound_choose.sound_choose(my_string_1)
speech_generation.speech_generation(my_string_2)
def Speech():
    return  0
